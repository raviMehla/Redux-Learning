import classes from "./Counter.module.css";

import { useSelector, useDispatch } from "react-redux";
import { counterActions } from "../store/reduxToolkit";

const Counter = () => {
  const dispathVal = useDispatch();
  const counterVal = useSelector((state) => state.count.counter);
  const show = useSelector((state) => state.count.showCounter);

  function increaseVal() {
    dispathVal(counterActions.increment());
  }

  function decreaseVal() {
    dispathVal(counterActions.decrement());
  }

  const toggleCounterHandler = () => {
    dispathVal(counterActions.toggle());
  };

  console.log("The value of Counter is :", counterVal);
  console.log("The value of Counter is :", counterVal);
  return (
    <main className={classes.counter}>
      <h1>Redux Counter</h1>
      {show && <div className={classes.value}>{counterVal}</div>}
      <button onClick={increaseVal}>Increase</button>
      <button onClick={decreaseVal}>Decrease</button>

      <button onClick={toggleCounterHandler}>Toggle Counter</button>
    </main>
  );
};

export default Counter;
