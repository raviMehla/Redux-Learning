import Counter from "./components/Counter.jsx";
import Header from "./components/Header.jsx";
import Auth from "../src/components/Auth.jsx";
import UserProfile from "../src/components/UserProfile.jsx";

import { useSelector } from "react-redux";
// import { authActions } from "../store/reduxToolkit";

function App() {
  const showProfile = useSelector((state) => state.auth.isAuthenticated);

  return (
    <>
      <Header />
      {showProfile ? <UserProfile /> : <Auth />}

      <Counter />
    </>
  );
}

export default App;
